---
navigation:
  parent: items-blocks-machines-index.md
  title: МЭ загадочный куб
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# МЭ загадочный куб

<BlockImage id="mysterious_cube" scale="8" />

Помните, когда приходилось искать кучу метеоритов, чтобы найти все клише? Больше не нужно! Теперь метеориты содержат МЭ загадочный куб.

Интересно, что произойдёт, если его сломать (без чар "Шёлковое касание")...

Также можно создать копию — МЭ не такой уж загадочный куб.

## Рецепт

<RecipeFor id="not_so_mysterious_cube" />