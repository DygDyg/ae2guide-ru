---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: МЭ заряженный посох
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# МЭ заряженный посох

<ItemImage id="charged_staff" scale="4" />

МЭ заряженный посох — это палка с <ItemLink id="charged_certus_quartz_crystal" /> на конце. Он наносит 6 единиц урона, используя 300 AE за атаку.

Его энергию можно перезарядить в <ItemLink id="charger" />.

## Рецепт

<RecipeFor id="charged_staff" />