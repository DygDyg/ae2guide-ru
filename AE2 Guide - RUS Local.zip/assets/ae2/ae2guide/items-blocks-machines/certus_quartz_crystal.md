---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кристалл истинного кварца
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# Кристалл истинного кварца

<ItemImage id="certus_quartz_crystal" scale="4" />

*"Кристаллы истинного кварца обладают уникальной способностью принимать большие количества энергии в свою кристаллическую матрицу"*

Один из основных ингредиентов для блоков, [устройств](../ae2-mechanics/devices.md) и предметов AE2. Получается путём выращивания из [цветущего истинного кварца](../ae2-mechanics/certus-growth.md).

## Некоторые альтернативные рецепты

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />