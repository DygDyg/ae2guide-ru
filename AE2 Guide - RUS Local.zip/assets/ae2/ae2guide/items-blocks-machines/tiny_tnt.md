---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Крохотный динамит
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Крохотный динамит

<BlockImage id="tiny_tnt" scale="8" />

Маленький динамит для небольших взрывов. Полезен для создания пар <ItemLink id="quantum_entangled_singularity" /> (Сингулярность квантовой запутанности).

В конфигурации можно отключить урон блоков, чтобы создавать сингулярности без риска разрушений, если вы хотите отключить динамит и крипперов на сервере.

## Рецепт

<RecipeFor id="tiny_tnt" />