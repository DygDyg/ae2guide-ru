---
navigation:
  parent: items-blocks-machines-index.md
  title: МЭ метеоритный компас
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# МЭ метеоритный компас

<ItemImage id="meteorite_compass" scale="4" />

МЭ метеоритный компас указывает на ближайший <ItemLink id="mysterious_cube" />, тем самым направляя к ближайшему [метеориту](../ae2-mechanics/meteorites.md). Это один из первых предметов AE2, который следует создать.

## Рецепт

<RecipeFor id="meteorite_compass" />