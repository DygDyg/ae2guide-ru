---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Бак из небесного камня
  icon: sky_stone_tank
  position: 310
categories:
- машины
item_ids:
- ae2:sky_stone_tank
---

# Бак из небесного камня

<BlockImage id="sky_stone_tank" scale="8" />

Это жидкостной бак, который вмещает 16 вёдер жидкости. Не сохраняет содержимое при подборе. Больше сказать нечего.

## Рецепт

<RecipeFor id="sky_stone_tank" />