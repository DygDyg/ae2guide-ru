---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Расширенный дисковод
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# МЭ Расширенный дисковод

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

МЭ Расширенный дисковод — это <ItemLink id="ae2:drive" /> с увеличенным инвентарём для ячеек хранения. Он может содержать до 20 ячеек хранения.