---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Расширенный порт ввода/вывода
    icon: extendedae:ex_io_port
categories:
- extended devices
item_ids:
- extendedae:ex_io_port
---

# МЭ Расширенный порт ввода/вывода

<Row gap="20">
<BlockImage id="extendedae:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

МЭ Расширенный порт ввода/вывода работает в 8 раз быстрее, чем обычный <ItemLink id="ae2:io_port" />.

Он также имеет больше слотов для улучшений по сравнению с обычным портом.