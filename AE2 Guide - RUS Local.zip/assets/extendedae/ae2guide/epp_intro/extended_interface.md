---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Расширенный интерфейс
    icon: extendedae:ex_interface
categories:
- extended devices
item_ids:
- extendedae:ex_interface
- extendedae:ex_interface_part
---

# МЭ Расширенный интерфейс

<Row gap="20">
<BlockImage id="extendedae:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

МЭ Расширенный интерфейс — это <ItemLink id="ae2:interface" /> с увеличенным инвентарём для конфигурации.

*Действительно ли мне это нужно?*

![EIGui](../pic/ei_gui.png)