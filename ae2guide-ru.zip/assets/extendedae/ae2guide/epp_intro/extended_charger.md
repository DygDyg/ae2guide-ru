---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенный зарядник
    icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# Расширенный зарядник

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

Расширенный зарядник — это усовершенствованный <ItemLink id="ae2:charger" />.

Он может заряжать до 4 предметов одновременно.