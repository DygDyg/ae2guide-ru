---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенный вырезатель
    icon: extendedae:ex_inscriber
categories:
- extended devices
item_ids:
- extendedae:ex_inscriber
---

# Расширенный вырезатель

<Row gap="20">
<BlockImage id="extendedae:ex_inscriber" scale="8"></BlockImage>
</Row>

Расширенный вырезатель — это усовершенствованный <ItemLink id="ae2:inscriber" />.

Он может выполнять до 4 задач вырезания одновременно.

Имеется кнопка, позволяющая изменять максимальный размер стака в инвентаре, как у обычного вырезателя.

Рекомендуется установить размер стака на 1 при использовании с <ItemLink id="ae2:pattern_provider" />, чтобы избежать возможных проблем.