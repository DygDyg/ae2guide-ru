---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Бесконечная ячейка
    icon: extendedae:infinity_cell
categories:
- extended items
item_ids:
- extendedae:infinity_cell
---

# МЭ Бесконечная ячейка

Простой способ хранения воды и булыжника в форме ячейки хранения.

<Row>
<ItemImage id="extendedae:infinity_cell" scale="4"></ItemImage>
</Row>

Они могут содержать до 2.1 миллиарда предметов или жидкостей, и вы можете извлекать бесконечное количество булыжника или воды из них или добавлять бесконечное количество булыжника или воды в них.