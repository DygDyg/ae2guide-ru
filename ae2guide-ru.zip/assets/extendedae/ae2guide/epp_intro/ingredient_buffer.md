---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Буфер ингредиентов
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# МЭ Буфер ингредиентов

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

Блок хранения, который может содержать до 36 типов любых материалов, от предметов до жидкостей.