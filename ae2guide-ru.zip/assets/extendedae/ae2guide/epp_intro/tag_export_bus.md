---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Шина экспорта по тегам
    icon: extendedae:tag_export_bus
categories:
- extended devices
item_ids:
- extendedae:tag_export_bus
---

# МЭ Шина экспорта по тегам

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

МЭ Шина экспорта по тегам — это <ItemLink id="ae2:export_bus" />, которую можно настроить на фильтрацию по тегам предметов или жидкостей.

Правила фильтрации совпадают с <ItemLink id="extendedae:tag_storage_bus" />.