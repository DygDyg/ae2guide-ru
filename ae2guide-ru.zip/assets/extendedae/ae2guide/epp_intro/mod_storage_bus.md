---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ Шина хранения по моду
    icon: extendedae:mod_storage_bus
categories:
- extended devices
item_ids:
- extendedae:mod_storage_bus
---

# МЭ Шина хранения по моду

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_storage_bus.snbt"></ImportStructure>
</GameScene>

МЭ Шина хранения по моду — это <ItemLink id="ae2:storage_bus" />, которую можно настроить на фильтрацию по названию мода или его ID.