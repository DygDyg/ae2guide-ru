---
navigation:
    title: Введение в Extended AE
    position: 60
---

# Расширьте вашу систему AE!

Extended AE возвращает некоторые функции AE из версий 1.7.10/1.12.2 для современной версии AE.

[Extended AE GitHub](https://github.com/GlodBlock/ExtendedAE) 

## Расширенные устройства
<CategoryIndex category="extended devices"></CategoryIndex>

## Расширенные предметы
<CategoryIndex category="extended items"></CategoryIndex>